# 🚀 Dockerize React App with Multi-Stage Build

This project demonstrates how to **Dockerize a React application** using a **multi-stage Docker build** for optimized image size and production deployment.

## 🧩 Steps

1. **Build the Docker Image**
   ```bash
   docker build -t react-app .
   ```

2. **Run the Docker Container**
   ```bash
   docker run -d -p 8080:80 react-app
   ```

3. **Open in Browser**
   Visit 👉 http://localhost:8080

## 📦 Files Included
- `Dockerfile` — Multi-stage Docker build for React and Nginx
- `.dockerignore` — Ignore unnecessary files
- `README.md` — Instructions for running the container
